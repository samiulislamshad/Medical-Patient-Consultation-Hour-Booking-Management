In case the program prompts about missing itextpdf-5.5.9.jar file, the jar file has also been provided inside the zip file. 
1. Click resolve and locate the included itextpdf-5.5.9.jar file.
 