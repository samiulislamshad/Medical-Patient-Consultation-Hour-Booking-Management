
package apumc;

import initialPages.WelcomePage;
import reportManagement.ReportManagementPage;

public class APUMC {
    
    public static void main(String[] args) {
//        LoginPage lp = new LoginPage();
//        lp.setVisible(true);
//        RegistrationPage rp = new RegistrationPage();
//        rp.setVisible(true);
//        WelcomePage wp = new WelcomePage();
//        wp.setVisible(true);
//        AdminPage ap = new AdminPage();
//        ap.setVisible(true);
//        AddUserForm auf = new AddUserForm(null, false);
//        auf.setVisible(true);
//        AddAppointmentForm aaf = new AddAppointmentForm(null, false);
//        aaf.setVisible(true);
        ReportManagementPage rmp = new ReportManagementPage();
        rmp.setVisible(true);
    }
    
}
