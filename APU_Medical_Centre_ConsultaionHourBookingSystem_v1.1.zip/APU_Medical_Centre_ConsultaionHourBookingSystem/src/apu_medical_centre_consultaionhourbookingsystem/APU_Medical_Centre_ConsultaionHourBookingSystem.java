/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apu_medical_centre_consultaionhourbookingsystem;

import initialPages.WelcomePage;

/**
 *
 * @author SUHA
 */
public class APU_Medical_Centre_ConsultaionHourBookingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        WelcomePage wp = new WelcomePage();
        wp.setVisible(true);
    }
    
}
